create function st_snaptogrid(rast raster, gridx double precision, gridy double precision, scalexy double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) returns raster
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_gdalwarp($1, $5, $6, NULL, $4, $4, $2, $3)
$$;

comment on function st_snaptogrid(raster, double precision, double precision, double precision, text, double precision) is 'args: rast, gridx, gridy, scalexy, algorithm=NearestNeighbour, maxerr=0.125 - Resample a raster by snapping it to a grid. New pixel values are computed using the NearestNeighbor (english or american spelling), Bilinear, Cubic, CubicSpline or Lanczos resampling algorithm. Default is NearestNeighbor.';

alter function st_snaptogrid(raster, double precision, double precision, double precision, text, double precision) owner to postgres;

