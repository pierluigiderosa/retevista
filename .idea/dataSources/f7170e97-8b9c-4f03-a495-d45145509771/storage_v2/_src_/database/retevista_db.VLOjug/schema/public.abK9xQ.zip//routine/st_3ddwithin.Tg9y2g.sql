create function st_3ddwithin(geom1 geometry, geom2 geometry, double precision) returns boolean
  immutable
  parallel safe
  language sql
as
$$
SELECT $1 OPERATOR(public.&&) public.ST_Expand($2,$3) AND $2 OPERATOR(public.&&) public.ST_Expand($1,$3) AND public._ST_3DDWithin($1, $2, $3)
$$;

comment on function st_3ddwithin(geometry, geometry, double precision) is 'args: g1, g2, distance_of_srid - For 3d (z) geometry type Returns true if two geometries 3d distance is within number of units.';

alter function st_3ddwithin(geometry, geometry, double precision) owner to postgres;

