create function st_coveredby(geography, geography) returns boolean
  immutable
  parallel safe
  language sql
as
$$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Covers($2, $1)
$$;

comment on function st_coveredby(geography, geography) is 'args: geogA, geogB - Returns 1 (TRUE) if no point in Geometry/Geography A is outside Geometry/Geography B';

alter function st_coveredby(geography, geography) owner to postgres;

