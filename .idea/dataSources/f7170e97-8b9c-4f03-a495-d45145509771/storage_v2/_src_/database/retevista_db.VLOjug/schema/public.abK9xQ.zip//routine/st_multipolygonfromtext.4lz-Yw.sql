create function st_multipolygonfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_MPolyFromText($1)
$$;

alter function st_multipolygonfromtext(text) owner to postgres;

