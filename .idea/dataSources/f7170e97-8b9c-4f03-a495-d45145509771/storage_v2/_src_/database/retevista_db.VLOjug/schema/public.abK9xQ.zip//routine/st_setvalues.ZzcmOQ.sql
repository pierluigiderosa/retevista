create function st_setvalues(rast raster, x integer, y integer, width integer, height integer, newvalue double precision, keepnodata boolean DEFAULT false) returns raster
    immutable
    parallel safe
    language plpgsql
as
$$
BEGIN
		IF width <= 0 OR height <= 0 THEN
			RAISE EXCEPTION 'Values for width and height must be greater than zero';
			RETURN NULL;
		END IF;
		RETURN public._ST_setvalues($1, 1, $2, $3, array_fill($6, ARRAY[$5, $4]::int[]), NULL, FALSE, NULL, $7);
	END;

$$;

comment on function st_setvalues(raster, integer, integer, integer, integer, double precision, boolean) is 'args: rast, columnx, rowy, width, height, newvalue, keepnodata=FALSE - Returns modified raster resulting from setting the values of a given band.';

alter function st_setvalues(raster, integer, integer, integer, integer, double precision, boolean) owner to postgres;

