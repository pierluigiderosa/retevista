create function st_mlinefromtext(text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'MULTILINESTRING'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END

$$;

comment on function st_mlinefromtext(text) is 'args: WKT - Return a specified ST_MultiLineString value from WKT representation.';

alter function st_mlinefromtext(text) owner to postgres;

