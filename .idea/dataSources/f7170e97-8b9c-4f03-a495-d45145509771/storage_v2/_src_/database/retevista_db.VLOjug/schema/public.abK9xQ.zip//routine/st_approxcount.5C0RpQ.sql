create function st_approxcount(rast raster, sample_percent double precision) returns bigint
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public._ST_count($1, 1, TRUE, $2)
$$;

alter function st_approxcount(raster, double precision) owner to postgres;

