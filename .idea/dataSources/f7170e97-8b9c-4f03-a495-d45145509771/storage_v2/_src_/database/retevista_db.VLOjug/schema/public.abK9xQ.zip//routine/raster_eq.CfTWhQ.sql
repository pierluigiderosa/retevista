create function raster_eq(raster, raster) returns boolean
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.raster_hash($1) = public.raster_hash($2)
$$;

alter function raster_eq(raster, raster) owner to postgres;

