create function geometry_raster_contain(geometry, raster) returns boolean
    immutable
    strict
    parallel safe
    language sql
as
$$
select $1 OPERATOR(public.~) $2::geometry
$$;

alter function geometry_raster_contain(geometry, raster) owner to postgres;

