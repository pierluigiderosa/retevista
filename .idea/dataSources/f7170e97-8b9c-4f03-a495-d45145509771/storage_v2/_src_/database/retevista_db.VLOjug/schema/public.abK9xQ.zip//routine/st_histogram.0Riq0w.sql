create function st_histogram(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, bins integer DEFAULT 0, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
    immutable
    parallel safe
    language sql
as
$$
SELECT min, max, count, percent FROM public._ST_histogram($1, $2, $3, 1, $4, $5, $6)
$$;

comment on function st_histogram(raster, integer, boolean, integer, double precision[], boolean, out double precision, out double precision, out bigint, out double precision) is 'args: rast, nband=1, exclude_nodata_value=true, bins=autocomputed, width=NULL, right=false - Returns a set of record summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(raster, integer, boolean, integer, double precision[], boolean, out double precision, out double precision, out bigint, out double precision) owner to postgres;

