create function st_linestringfromwkb(bytea, integer) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN public.ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;

comment on function st_linestringfromwkb(bytea, integer) is 'args: WKB, srid - Makes a geometry from WKB with the given SRID.';

alter function st_linestringfromwkb(bytea, integer) owner to postgres;

