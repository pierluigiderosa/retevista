create function st_dwithin(text, text, double precision) returns boolean
  immutable
  language sql
as
$$
SELECT ST_DWithin($1::public.geometry, $2::public.geometry, $3);
$$;

alter function st_dwithin(text, text, double precision) owner to postgres;

