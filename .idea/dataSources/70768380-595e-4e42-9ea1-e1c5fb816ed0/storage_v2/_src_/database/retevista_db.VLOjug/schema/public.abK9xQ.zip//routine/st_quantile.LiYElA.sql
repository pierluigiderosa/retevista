create function st_quantile(rast raster, exclude_nodata_value boolean, quantile double precision DEFAULT NULL::double precision) returns double precision
    immutable
    language sql
as
$$
SELECT ( public._ST_quantile($1, 1, $2, 1, ARRAY[$3]::double precision[])).value
$$;

comment on function st_quantile(raster, boolean, double precision) is 'args: rast, exclude_nodata_value, quantile=NULL - Compute quantiles for a raster or raster table coverage in the context of the sample or population. Thus, a value could be examined to be at the rasters 25%, 50%, 75% percentile.';

alter function st_quantile(raster, boolean, double precision) owner to postgres;

