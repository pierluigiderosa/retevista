create function st_worldtorastercoord(rast raster, longitude double precision, latitude double precision, OUT columnx integer, OUT rowy integer) returns record
    immutable
    strict
    language sql
as
$$
SELECT columnx, rowy FROM public._ST_worldtorastercoord($1, $2, $3)
$$;

comment on function st_worldtorastercoord(raster, double precision, double precision, out integer, out integer) is 'args: rast, longitude, latitude - Returns the upper left corner as column and row given geometric X and Y (longitude and latitude) or a point geometry expressed in the spatial reference coordinate system of the raster.';

alter function st_worldtorastercoord(raster, double precision, double precision, out integer, out integer) owner to postgres;

