create function st_addband(rast raster, outdbfile text, outdbindex integer[], index integer DEFAULT NULL::integer, nodataval double precision DEFAULT NULL::double precision) returns raster
    immutable
    language sql
as
$$
SELECT public.ST_AddBand($1, $4, $2, $3, $5)
$$;

comment on function st_addband(raster, text, integer[], integer, double precision) is 'args: rast, outdbfile, outdbindex, index=at_end, nodataval=NULL - Returns a raster with the new band(s) of given type added with given initial value in the given index location. If no index is specified, the band is added to the end.';

alter function st_addband(raster, text, integer[], integer, double precision) owner to postgres;

