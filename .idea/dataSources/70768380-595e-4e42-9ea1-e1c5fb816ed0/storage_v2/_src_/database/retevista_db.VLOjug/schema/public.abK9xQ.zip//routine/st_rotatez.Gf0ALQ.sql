create function st_rotatez(geometry, double precision) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT public.ST_Rotate($1, $2)
$$;

comment on function st_rotatez(geometry, double precision) is 'args: geomA, rotRadians - Rotate a geometry rotRadians about the Z axis.';

alter function st_rotatez(geometry, double precision) owner to postgres;

