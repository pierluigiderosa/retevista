create function st_curvetoline(geometry) returns geometry
  immutable
  strict
  language sql
as
$$
SELECT ST_CurveToLine($1, 32::integer)
$$;

comment on function st_curvetoline(geometry) is 'args: curveGeom - Converts a CIRCULARSTRING/CURVEPOLYGON to a LINESTRING/POLYGON';

alter function st_curvetoline(geometry) owner to postgres;

