create function st_force_3d(geometry) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT public._postgis_deprecate('ST_Force_3d', 'ST_Force3D', '2.1.0');
    SELECT public.ST_Force3D($1);
$$;

alter function st_force_3d(geometry) owner to postgres;

