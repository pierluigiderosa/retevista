create function st_worldtorastercoordy(rast raster, xw double precision, yw double precision) returns integer
  immutable
  strict
  language sql
as
$$
SELECT rowy FROM public._ST_worldtorastercoord($1, $2, $3)
$$;

comment on function st_worldtorastercoordy(raster, double precision, double precision) is 'args: rast, xw, yw - Returns the row in the raster of the point geometry (pt) or a X and Y world coordinate (xw, yw) represented in world spatial reference system of raster.';

alter function st_worldtorastercoordy(raster, double precision, double precision) owner to postgres;

