create function st_value(rast raster, pt geometry, exclude_nodata_value boolean DEFAULT true) returns double precision
  immutable
  strict
  language sql
as
$$
SELECT public.ST_value($1, 1, $2, $3)
$$;

comment on function st_value(raster, geometry, boolean) is 'args: rast, pt, exclude_nodata_value=true - Returns the value of a given band in a given columnx, rowy pixel or at a particular geometric point. Band numbers start at 1 and assumed to be 1 if not specified. If exclude_nodata_value is set to false, then all pixels include nodata pixels are considered to intersect and return value. If exclude_nodata_value is not passed in then reads it from metadata of raster.';

alter function st_value(raster, geometry, boolean) owner to postgres;

