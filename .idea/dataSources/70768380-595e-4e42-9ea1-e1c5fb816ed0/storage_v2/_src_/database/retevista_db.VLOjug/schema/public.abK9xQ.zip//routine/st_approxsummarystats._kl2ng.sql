create function st_approxsummarystats(rast raster, sample_percent double precision) returns summarystats
  immutable
  strict
  language sql
as
$$
SELECT public._ST_summarystats($1, 1, TRUE, $2)
$$;

alter function st_approxsummarystats(raster, double precision) owner to postgres;

