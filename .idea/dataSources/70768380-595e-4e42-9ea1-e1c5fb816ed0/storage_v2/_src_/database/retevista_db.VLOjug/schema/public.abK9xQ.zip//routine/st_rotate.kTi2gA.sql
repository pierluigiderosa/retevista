create function st_rotate(geometry, double precision, double precision, double precision) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT public.ST_Affine($1,  cos($2), -sin($2), 0,  sin($2),  cos($2), 0, 0, 0, 1,	$3 - cos($2) * $3 + sin($2) * $4, $4 - sin($2) * $3 - cos($2) * $4, 0)
$$;

comment on function st_rotate(geometry, double precision, double precision, double precision) is 'args: geomA, rotRadians, x0, y0 - Rotate a geometry rotRadians counter-clockwise about an origin.';

alter function st_rotate(geometry, double precision, double precision, double precision) owner to postgres;

